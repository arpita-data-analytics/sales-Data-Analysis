# Sales Data Analysis

## Objective
Analyze sales data to identify trends, top products, and regional performance.

## Tools Used
- Python (Pandas, Matplotlib)
- Excel
- SQL (optional)

## Key Analysis
- Total sales calculation
- Sales by region
- Top-selling products
- Sales distribution by region

## Key Insights
- East region generates the highest sales, showing strong market demand.
- South region has the lowest sales and may need targeted marketing.
- Sales are unevenly distributed across regions.

## Conclusion
This analysis helps businesses understand sales performance and make data-driven decisions.

